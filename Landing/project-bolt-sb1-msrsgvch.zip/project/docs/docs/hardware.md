---
sidebar_position: 2
---

# Hardware Specifications

## Overview

The Nova34 is an ultra-compact Linux board measuring just 65mm x 34mm x 10mm. Despite its small size, it packs impressive computing power and connectivity options.

## System on Chip (SoC)

- **Processor**: Quad-core ARM Cortex-A53, 1.5GHz
- **GPU**: Mali-400 MP2
- **Memory**: 1GB LPDDR4
- **Storage**: 8GB eMMC, MicroSD slot for expansion

## Connectivity

### Wireless

- **Wi-Fi**: 802.11ac (Wi-Fi 5), dual-band 2.4GHz and 5GHz
- **Bluetooth**: Bluetooth 5.0 BLE

### Wired

- **Ethernet**: 10/100 Mbps
- **USB**: 1x USB 3.0, 1x USB 2.0
- **GPIO**: 40-pin header compatible with popular accessories

## Power

- **Input**: 5V DC via USB-C
- **Consumption**: 1.5W - 3W typical
- **Battery**: Optional LiPo connector for portable applications
- **Power Modes**: Active, Sleep, Deep Sleep for power optimization

## Physical Specifications

- **Dimensions**: 65mm x 34mm x 10mm
- **Weight**: 15g
- **Operating Temperature**: 0°C to 70°C
- **Storage Temperature**: -40°C to 85°C

## GPIO Pinout

The Nova34 features a 40-pin GPIO header with the following configuration:

```
   3.3V [1]  [2]  5V
GPIO2/I2C [3]  [4]  5V
GPIO3/I2C [5]  [6]  GND
   GPIO4 [7]  [8]  GPIO14/UART
     GND [9]  [10] GPIO15/UART
  GPIO17 [11] [12] GPIO18/PWM
  GPIO27 [13] [14] GND
  GPIO22 [15] [16] GPIO23
    3.3V [17] [18] GPIO24
GPIO10/SPI [19] [20] GND
GPIO9/SPI [21] [22] GPIO25
GPIO11/SPI [23] [24] GPIO8/SPI
     GND [25] [26] GPIO7
  GPIO0/ID [27] [28] GPIO1/ID
   GPIO5 [29] [30] GND
   GPIO6 [31] [32] GPIO12/PWM
GPIO13/PWM [33] [34] GND
GPIO19/PWM [35] [36] GPIO16
  GPIO26 [37] [38] GPIO20
     GND [39] [40] GPIO21
```

## Interfaces

### Display

- **HDMI**: Mini-HDMI port supporting up to 1080p60
- **MIPI DSI**: 15-pin connector for compatible displays

### Audio

- **Output**: Via HDMI
- **Input/Output**: 3.5mm audio jack

### Camera

- **MIPI CSI**: 15-pin connector for compatible cameras

## PCB Design

The Nova34 is designed with a 4-layer PCB for optimal signal integrity and thermal performance. The board layout has been carefully optimized to minimize interference between components and maximize performance.

## Thermal Management

The SoC includes an integrated thermal management system that monitors temperature and adjusts performance to prevent overheating. For applications requiring sustained high performance, a small heatsink can be attached to the designated mounting points.

## Expansion Options

In addition to the GPIO header, the Nova34 supports expansion through:

- **M.2 E-Key**: For Wi-Fi/Bluetooth modules (on select models)
- **I2C, SPI, UART**: Available through the GPIO header
- **USB**: Connect external peripherals

## Certifications

- CE
- FCC
- RoHS
- REACH