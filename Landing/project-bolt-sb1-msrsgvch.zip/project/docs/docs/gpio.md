---
sidebar_position: 4
---

# GPIO Programming

## Introduction to GPIO

The Nova34 features a 40-pin GPIO (General Purpose Input/Output) header that allows you to connect and control external hardware. These pins can be configured as inputs or outputs, and some have special functions like I2C, SPI, UART, and PWM.

## GPIO Library

The Nova34 comes with a Python library for easy GPIO control:

```bash
# Install the Nova34 GPIO library
pip install nova34-gpio
```

## Basic GPIO Operations

### Setting Up GPIO Pins

```python
import nova34.gpio as gpio

# Initialize GPIO
gpio.init()

# Set a pin as output
gpio.setup(18, gpio.OUT)

# Set a pin as input
gpio.setup(17, gpio.IN)

# Set a pin as input with pull-up resistor
gpio.setup(17, gpio.IN, gpio.PUD_UP)
```

### Reading and Writing GPIO

```python
# Write HIGH to a pin
gpio.output(18, gpio.HIGH)

# Write LOW to a pin
gpio.output(18, gpio.LOW)

# Read from a pin
value = gpio.input(17)
print(f"Pin 17 value: {value}")
```

### Cleanup

Always clean up GPIO resources when your program exits:

```python
# Clean up all GPIO pins
gpio.cleanup()

# Clean up specific pins
gpio.cleanup(18)
```

## Interrupt-Based GPIO

For efficient event-driven programming, you can use interrupts:

```python
import nova34.gpio as gpio
import time

def button_callback(channel):
    print(f"Button pressed on channel {channel}")

# Set up the button pin
button_pin = 17
gpio.setup(button_pin, gpio.IN, pull_up_down=gpio.PUD_UP)

# Add event detection
gpio.add_event_detect(button_pin, gpio.FALLING, callback=button_callback, bouncetime=200)

# Keep the program running
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    gpio.cleanup()
```

## PWM (Pulse Width Modulation)

PWM is useful for controlling LED brightness, motor speed, and more:

```python
import nova34.gpio as gpio
import time

# Set up PWM pin
led_pin = 18
gpio.setup(led_pin, gpio.OUT)

# Create PWM instance at 100Hz
pwm = gpio.PWM(led_pin, 100)

# Start PWM with 0% duty cycle
pwm.start(0)

try:
    # Fade in
    for duty_cycle in range(0, 101, 5):
        pwm.ChangeDutyCycle(duty_cycle)
        time.sleep(0.1)
    
    # Fade out
    for duty_cycle in range(100, -1, -5):
        pwm.ChangeDutyCycle(duty_cycle)
        time.sleep(0.1)
        
finally:
    # Clean up
    pwm.stop()
    gpio.cleanup()
```

## I2C Interface

I2C is used for connecting sensors, displays, and other peripherals:

```python
import smbus
import time

# Create I2C bus instance
bus = smbus.SMBus(1)  # Use bus 1 on Nova34

# I2C address of the device
address = 0x48

try:
    # Write to a register
    bus.write_byte_data(address, 0x01, 0x55)
    
    # Read from a register
    value = bus.read_byte_data(address, 0x00)
    print(f"Read value: {value}")
    
except Exception as e:
    print(f"Error: {e}")
```

## SPI Interface

SPI is useful for high-speed communication with peripherals:

```python
import spidev
import time

# Create SPI instance
spi = spidev.SpiDev()
spi.open(0, 0)  # Bus 0, Device 0
spi.max_speed_hz = 1000000  # 1MHz

try:
    # Send data
    response = spi.xfer2([0x01, 0x02, 0x03])
    print(f"Received: {response}")
    
finally:
    spi.close()
```

## UART Serial Communication

UART is used for serial communication with other devices:

```python
import serial
import time

# Open serial port
ser = serial.Serial(
    port='/dev/ttyS0',  # UART on GPIO pins 8 and 10
    baudrate=9600,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.EIGHTBITS,
    timeout=1
)

try:
    # Send data
    ser.write(b'Hello from Nova34!\n')
    
    # Read data
    while True:
        if ser.in_waiting > 0:
            line = ser.readline().decode('utf-8').rstrip()
            print(f"Received: {line}")
            
except KeyboardInterrupt:
    ser.close()
```

## GPIO Safety Considerations

- **Voltage Levels**: Nova34 GPIO pins operate at 3.3V. Connecting them to 5V sources without level shifting can damage your board.
- **Current Limits**: Each GPIO pin can source or sink a maximum of 16mA. Exceeding this can damage the pin or the board.
- **Short Circuits**: Always double-check your wiring to avoid short circuits.
- **ESD Protection**: Use proper ESD protection when handling the board.
- **External Components**: Use resistors when connecting LEDs and other components to limit current.

## Example Projects

- [LED Blink](/docs/examples/led-blink)
- [Button Input](/docs/examples/button-input)
- [Temperature Sensor](/docs/examples/temperature-sensor)
- [OLED Display](/docs/examples/oled-display)
- [Motor Control](/docs/examples/motor-control)