---
sidebar_position: 5
---

# Example Projects

This section contains a collection of example projects to help you get started with your Nova34 board. Each example includes complete code, wiring diagrams, and explanations.

## LED Blink

The classic "Hello World" of hardware programming - making an LED blink.

### Components Needed

- Nova34 board
- LED (any color)
- 220Ω resistor
- Jumper wires

### Wiring

1. Connect the longer leg (anode) of the LED to GPIO pin 18 through a 220Ω resistor
2. Connect the shorter leg (cathode) of the LED to a GND pin

### Code

```python
import nova34.gpio as gpio
import time

# Set up GPIO
led_pin = 18
gpio.init()
gpio.setup(led_pin, gpio.OUT)

try:
    while True:
        # Turn LED on
        gpio.output(led_pin, gpio.HIGH)
        print("LED on")
        time.sleep(1)
        
        # Turn LED off
        gpio.output(led_pin, gpio.LOW)
        print("LED off")
        time.sleep(1)
        
except KeyboardInterrupt:
    # Clean up on exit
    gpio.cleanup()
    print("Program ended")
```

## Weather Station

Create a simple weather station that measures temperature, humidity, and pressure.

### Components Needed

- Nova34 board
- BME280 sensor (I2C)
- OLED display (I2C, 128x64 pixels)
- Jumper wires

### Wiring

1. Connect the BME280 VCC to 3.3V
2. Connect the BME280 GND to GND
3. Connect the BME280 SCL to GPIO3 (I2C SCL)
4. Connect the BME280 SDA to GPIO2 (I2C SDA)
5. Connect the OLED VCC to 3.3V
6. Connect the OLED GND to GND
7. Connect the OLED SCL to GPIO3 (I2C SCL)
8. Connect the OLED SDA to GPIO2 (I2C SDA)

### Code

```python
import time
import board
import adafruit_bme280
import adafruit_ssd1306
from PIL import Image, ImageDraw, ImageFont

# Set up I2C
i2c = board.I2C()

# Set up BME280 sensor
bme280 = adafruit_bme280.Adafruit_BME280_I2C(i2c, address=0x76)

# Set up OLED display
display = adafruit_ssd1306.SSD1306_I2C(128, 64, i2c, addr=0x3C)

# Load a font
font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 10)

try:
    while True:
        # Read sensor data
        temperature = bme280.temperature
        humidity = bme280.humidity
        pressure = bme280.pressure / 100  # Convert Pa to hPa
        
        # Create blank image for drawing
        image = Image.new("1", (display.width, display.height))
        draw = ImageDraw.Draw(image)
        
        # Draw the data on the image
        draw.text((0, 0), "Nova34 Weather Station", font=font, fill=255)
        draw.text((0, 16), f"Temp: {temperature:.1f} °C", font=font, fill=255)
        draw.text((0, 32), f"Humidity: {humidity:.1f} %", font=font, fill=255)
        draw.text((0, 48), f"Pressure: {pressure:.1f} hPa", font=font, fill=255)
        
        # Display the image
        display.image(image)
        display.show()
        
        # Wait before next reading
        time.sleep(5)
        
except KeyboardInterrupt:
    # Clear the display on exit
    display.fill(0)
    display.show()
    print("Program ended")
```

## Home Automation Hub

Create a simple home automation hub that can control lights and monitor temperature.

### Components Needed

- Nova34 board
- DHT22 temperature/humidity sensor
- Relay module (for controlling lights)
- Jumper wires

### Wiring

1. Connect the DHT22 VCC to 3.3V
2. Connect the DHT22 GND to GND
3. Connect the DHT22 DATA to GPIO4
4. Connect the Relay VCC to 5V
5. Connect the Relay GND to GND
6. Connect the Relay IN to GPIO18

### Code

```python
import time
import nova34.gpio as gpio
import Adafruit_DHT

# Set up GPIO
gpio.init()

# Set up DHT22 sensor
dht_pin = 4
sensor = Adafruit_DHT.DHT22

# Set up relay
relay_pin = 18
gpio.setup(relay_pin, gpio.OUT)
gpio.output(relay_pin, gpio.LOW)  # Start with relay off

# Temperature thresholds
temp_high = 25.0  # Turn on fan if temperature exceeds this
temp_low = 23.0   # Turn off fan if temperature falls below this

try:
    while True:
        # Read temperature and humidity
        humidity, temperature = Adafruit_DHT.read_retry(sensor, dht_pin)
        
        if humidity is not None and temperature is not None:
            print(f"Temperature: {temperature:.1f}°C, Humidity: {humidity:.1f}%")
            
            # Control relay based on temperature
            if temperature > temp_high:
                gpio.output(relay_pin, gpio.HIGH)  # Turn on relay
                print("Relay ON")
            elif temperature < temp_low:
                gpio.output(relay_pin, gpio.LOW)   # Turn off relay
                print("Relay OFF")
        else:
            print("Failed to read from DHT sensor")
        
        # Wait before next reading
        time.sleep(10)
        
except KeyboardInterrupt:
    # Clean up on exit
    gpio.output(relay_pin, gpio.LOW)  # Turn off relay
    gpio.cleanup()
    print("Program ended")
```

## Web Server for Remote Monitoring

Create a web server that displays sensor data and allows remote control of GPIO pins.

### Components Needed

- Nova34 board
- DHT22 temperature/humidity sensor
- LED (any color)
- 220Ω resistor
- Jumper wires

### Wiring

1. Connect the DHT22 VCC to 3.3V
2. Connect the DHT22 GND to GND
3. Connect the DHT22 DATA to GPIO4
4. Connect the LED anode to GPIO18 through a 220Ω resistor
5. Connect the LED cathode to GND

### Code

```python
from flask import Flask, render_template, request, jsonify
import nova34.gpio as gpio
import Adafruit_DHT
import threading
import time

app = Flask(__name__)

# Set up GPIO
gpio.init()

# Set up DHT22 sensor
dht_pin = 4
sensor = Adafruit_DHT.DHT22

# Set up LED
led_pin = 18
gpio.setup(led_pin, gpio.OUT)
gpio.output(led_pin, gpio.LOW)  # Start with LED off

# Global variables for sensor data
temperature = 0
humidity = 0
last_updated = "Never"

# Function to read sensor data in the background
def sensor_loop():
    global temperature, humidity, last_updated
    
    while True:
        hum, temp = Adafruit_DHT.read_retry(sensor, dht_pin)
        
        if hum is not None and temp is not None:
            temperature = round(temp, 1)
            humidity = round(hum, 1)
            last_updated = time.strftime("%Y-%m-%d %H:%M:%S")
        
        time.sleep(10)  # Read every 10 seconds

# Start the sensor reading thread
sensor_thread = threading.Thread(target=sensor_loop, daemon=True)
sensor_thread.start()

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/data')
def get_data():
    return jsonify({
        'temperature': temperature,
        'humidity': humidity,
        'last_updated': last_updated
    })

@app.route('/api/led/<state>')
def control_led(state):
    if state == 'on':
        gpio.output(led_pin, gpio.HIGH)
        return jsonify({'status': 'success', 'led': 'on'})
    elif state == 'off':
        gpio.output(led_pin, gpio.LOW)
        return jsonify({'status': 'success', 'led': 'off'})
    else:
        return jsonify({'status': 'error', 'message': 'Invalid state'})

if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0', port=8080)
    finally:
        gpio.cleanup()
```

### HTML Template

Create a file named `index.html` in a `templates` folder:

```html
<!DOCTYPE html>
<html>
<head>
    <title>Nova34 Remote Monitoring</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .controls {
            display: flex;
            gap: 10px;
        }
        button {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .on {
            background-color: #4CAF50;
            color: white;
        }
        .off {
            background-color: #f44336;
            color: white;
        }
    </style>
</head>
<body>
    <h1>Nova34 Remote Monitoring</h1>
    
    <div class="card">
        <h2>Sensor Data</h2>
        <p>Temperature: <span id="temperature">--</span> °C</p>
        <p>Humidity: <span id="humidity">--</span> %</p>
        <p>Last updated: <span id="last-updated">--</span></p>
    </div>
    
    <div class="card">
        <h2>LED Control</h2>
        <div class="controls">
            <button class="on" onclick="controlLED('on')">Turn On</button>
            <button class="off" onclick="controlLED('off')">Turn Off</button>
        </div>
    </div>
    
    <script>
        // Update sensor data every 5 seconds
        function updateData() {
            fetch('/api/data')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('temperature').textContent = data.temperature;
                    document.getElementById('humidity').textContent = data.humidity;
                    document.getElementById('last-updated').textContent = data.last_updated;
                });
        }
        
        // Control LED
        function controlLED(state) {
            fetch(`/api/led/${state}`)
                .then(response => response.json())
                .then(data => {
                    console.log(data);
                });
        }
        
        // Initial data load
        updateData();
        
        // Set up interval for updates
        setInterval(updateData, 5000);
    </script>
</body>
</html>
```

## More Examples

For more examples and detailed tutorials, check out:

- [Robot Control](/docs/examples/robot)
- [Camera Applications](/docs/examples/camera)
- [Audio Processing](/docs/examples/audio)
- [Machine Learning](/docs/examples/machine-learning)