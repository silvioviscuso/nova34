---
sidebar_position: 1
---

# Getting Started with Nova34

Welcome to the Nova34 documentation! This guide will help you get started with your Nova34 board.

## What is Nova34?

Nova34 is a general purpose ultra small Linux board designed for IoT, embedded systems, and edge computing applications. With its compact size (65mm x 34mm) and powerful features, it's perfect for a wide range of projects.

## Unboxing Your Nova34

Your Nova34 package should include:

- Nova34 board
- USB-C power cable
- Quick start guide
- Optional accessories (if purchased)

## First Boot

To get started with your Nova34:

1. Connect the USB-C power cable to the board and a power source
2. Wait for the power LED to illuminate
3. The board will automatically boot into Linux
4. For first-time setup, connect to the board via:
   - HDMI display and USB keyboard/mouse
   - Serial console (115200 baud)
   - SSH over network (if using the pre-configured image)

## Default Credentials

If you're using the standard Nova34 OS image:

- Username: `nova`
- Password: `nova34`

We strongly recommend changing the default password after your first login.

## Connecting to Wi-Fi

To connect your Nova34 to a Wi-Fi network:

```bash
sudo nmcli device wifi connect "YOUR_SSID" password "YOUR_PASSWORD"
```

## Updating Your System

Keep your Nova34 up to date with:

```bash
sudo apt update
sudo apt upgrade
```

## Next Steps

Now that you have your Nova34 up and running, check out these resources:

- [Hardware Specifications](/docs/hardware) - Detailed hardware information
- [Software Guide](/docs/software) - Software and OS information
- [GPIO Programming](/docs/gpio) - How to use the GPIO pins
- [Example Projects](/docs/examples) - Inspiration for your next project