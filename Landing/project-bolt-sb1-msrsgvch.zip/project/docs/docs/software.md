---
sidebar_position: 3
---

# Software Guide

## Operating System

The Nova34 comes with a custom Linux distribution based on Debian, optimized for the board's hardware. This provides a familiar environment for Linux users while ensuring compatibility with the Nova34's specific features.

## Pre-installed Software

The standard Nova34 OS image includes:

- Python 3.9
- Node.js 18 LTS
- Git
- Docker
- Basic development tools

## Development Environments

### Python

Python is pre-installed and ready to use for GPIO control, sensor integration, and application development:

```python
import nova34.gpio as gpio

# Set up a pin as output
led_pin = 18
gpio.setup(led_pin, gpio.OUT)

# Turn on the LED
gpio.output(led_pin, gpio.HIGH)
```

### Node.js

For web applications and IoT projects, Node.js is available:

```javascript
const { GPIO } = require('nova34-gpio');

// Configure GPIO pin
const led = new GPIO(18, 'out');

// Turn on LED
led.write(1);
```

### C/C++

For performance-critical applications, C/C++ development is supported:

```c
#include <nova34/gpio.h>
#include <stdio.h>

int main() {
    // Initialize GPIO
    if (gpio_init() < 0) {
        printf("Failed to initialize GPIO\n");
        return 1;
    }
    
    // Set pin mode
    gpio_set_mode(18, GPIO_MODE_OUTPUT);
    
    // Set pin high
    gpio_write(18, 1);
    
    return 0;
}
```

## Package Management

The Nova34 uses APT for package management:

```bash
# Update package lists
sudo apt update

# Install a package
sudo apt install python3-numpy

# Upgrade all packages
sudo apt upgrade
```

## Nova34 SDK

The Nova34 SDK provides libraries and tools for developing applications specifically for the Nova34 hardware:

```bash
# Install the Nova34 SDK
sudo apt install nova34-sdk

# Create a new project
nova34-create-project myproject
```

## Flashing a New OS

To flash a new operating system to your Nova34:

1. Download the OS image from the [Nova34 downloads page](https://nova34-docs.example.com/downloads)
2. Write the image to a microSD card using a tool like Etcher or dd
3. Insert the microSD card into your Nova34
4. Power on the board while holding the BOOT button
5. The board will boot from the microSD card and begin the installation process

## Backup and Restore

It's recommended to back up your Nova34 configuration and data regularly:

```bash
# Backup user data
sudo nova34-backup /path/to/backup/location

# Restore from backup
sudo nova34-restore /path/to/backup/file
```

## Troubleshooting

### Recovery Mode

If your Nova34 won't boot normally, you can enter recovery mode:

1. Power off the board
2. Hold the RECOVERY button
3. Power on the board while holding the button
4. Release the button after 5 seconds

### System Logs

Check system logs for troubleshooting:

```bash
# View kernel messages
dmesg

# View system logs
journalctl -xe
```

### Support Resources

If you encounter issues with your Nova34:

- Check the [Troubleshooting Guide](/docs/troubleshooting)
- Visit the [Community Forum](https://forum.nova34.org)
- Open an issue on [GitHub](https://github.com/yourusername/nova34/issues)